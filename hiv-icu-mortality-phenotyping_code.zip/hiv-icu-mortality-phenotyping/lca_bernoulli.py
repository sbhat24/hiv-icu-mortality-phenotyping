"""
Bernoulli latent class analysis (finite mixture) via expectation-maximization.

Fits a latent class model to binary indicator variables, selects the number of
classes by the Bayesian Information Criterion (BIC), and reports relative entropy
as a measure of classification certainty. Author-implemented; validated against
established latent-class packages (e.g., poLCA) to within numerical tolerance.

Usage:
    python lca_bernoulli.py --data indicators.csv --id record_id --kmin 2 --kmax 8

Input CSV: one row per subject, an ID column, and one column per binary indicator
(values coded 0/1 or Yes/No). No missing values in the indicator matrix.

Outputs:
    - BIC/AIC/entropy table for K = kmin..kmax
    - assignments CSV (id, class) for the BIC-optimal solution, classes numbered
      by ascending mean of an optional outcome column (or by size if none given)
"""
import argparse
import numpy as np
import pandas as pd
from scipy.special import logsumexp

EPS = 1e-3  # clip for theta to avoid log(0)

def _coerce(series):
    if pd.api.types.is_numeric_dtype(series):
        return series.astype(float).values
    return series.map(lambda v: 1.0 if str(v).strip() in ("Yes", "1", "True", "Y") else 0.0).values

def fit_em(X, K, seed, max_iter=800, tol=1e-7):
    """Single EM run for a K-class Bernoulli mixture. Returns theta, pi, loglik, resp."""
    rng = np.random.default_rng(seed)
    N, J = X.shape
    theta = np.clip(rng.uniform(0.1, 0.9, size=(K, J)), EPS, 1 - EPS)
    pi = np.full(K, 1.0 / K)
    ll_old = -np.inf
    for _ in range(max_iter):
        lt, l1t = np.log(theta), np.log(1 - theta)
        logp = X @ lt.T + (1 - X) @ l1t.T + np.log(pi)      # N x K
        ll = np.sum(logsumexp(logp, axis=1))
        resp = np.exp(logp - logsumexp(logp, axis=1, keepdims=True))
        Nk = resp.sum(0)
        pi = Nk / N
        theta = np.clip((resp.T @ X) / Nk[:, None], EPS, 1 - EPS)
        if abs(ll - ll_old) < tol:
            break
        ll_old = ll
    return theta, pi, ll, resp

def fit_best(X, K, restarts=120, seed0=42):
    """Fit K classes with multiple random restarts; keep the highest-likelihood solution."""
    best = None
    for s in range(restarts):
        res = fit_em(X, K, seed0 + s)
        if best is None or res[2] > best[2]:
            best = res
    theta, pi, ll, resp = best
    N, J = X.shape
    n_params = (K - 1) + K * J
    bic = -2 * ll + n_params * np.log(N)
    aic = -2 * ll + 2 * n_params
    rr = np.clip(resp, 1e-12, 1)
    entropy = 1 - (-(rr * np.log(rr)).sum()) / (N * np.log(K)) if K > 1 else 1.0
    return dict(K=K, loglik=ll, bic=bic, aic=aic, entropy=entropy,
                theta=theta, pi=pi, resp=resp)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--id", default="record_id")
    ap.add_argument("--indicators", nargs="*", default=None,
                    help="indicator column names; default = all columns except id/outcome")
    ap.add_argument("--outcome", default=None, help="optional binary outcome to order classes by")
    ap.add_argument("--kmin", type=int, default=2)
    ap.add_argument("--kmax", type=int, default=8)
    ap.add_argument("--restarts", type=int, default=120)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="lca_assignments.csv")
    a = ap.parse_args()

    df = pd.read_csv(a.data)
    ind = a.indicators or [c for c in df.columns if c not in (a.id, a.outcome)]
    X = np.column_stack([_coerce(df[c]) for c in ind]).astype(float)

    print(f"{'K':>2} {'logL':>10} {'BIC':>10} {'AIC':>10} {'entropy':>8}")
    res = {}
    for K in range(a.kmin, a.kmax + 1):
        o = fit_best(X, K, restarts=a.restarts, seed0=a.seed)
        res[K] = o
        print(f"{K:>2} {o['loglik']:>10.1f} {o['bic']:>10.1f} {o['aic']:>10.1f} {o['entropy']:>8.3f}")
    bestK = min(res, key=lambda k: res[k]['bic'])
    print(f"\nBIC-optimal K = {bestK} (entropy {res[bestK]['entropy']:.3f})")

    lab = res[bestK]['resp'].argmax(1)  # modal assignment, 0-indexed
    if a.outcome is not None:
        y = _coerce(df[a.outcome])
        order = pd.DataFrame({'lab': lab, 'y': y}).groupby('lab')['y'].mean().sort_values().index.tolist()
    else:
        order = pd.Series(lab).value_counts().sort_values().index.tolist()
    remap = {old: i + 1 for i, old in enumerate(order)}
    cls = np.array([remap[l] for l in lab])
    pd.DataFrame({a.id: df[a.id].values, "class": cls}).to_csv(a.out, index=False)
    print(f"Assignments written to {a.out}")

if __name__ == "__main__":
    main()
