# HIV-ICU Mortality Phenotyping — Analysis Code

Author-implemented statistical routines supporting the manuscript
*"[Manuscript Title]"* (Bhat S, et al.), a retrospective cohort study of
predictors of in-ICU mortality and latent clinical phenotypes among people
with HIV admitted to the intensive care unit.

This repository contains **code only**. The clinical dataset is not included
and is not publicly available owing to institutional and patient-privacy
restrictions; it may be shared on reasonable request, subject to institutional
review board approval.

## Contents

| File | Purpose |
|------|---------|
| `lca_bernoulli.py` | Bernoulli latent class analysis via EM, with multiple random restarts, BIC-based class selection, relative entropy, and modal class assignment (classes ordered by ascending outcome rate). |
| `firth_logistic.py` | Firth penalized-likelihood logistic regression (coefficients, penalized-information standard errors, Wald CIs, p-values); Rubin's-rules pooling across multiple imputations; AUROC with bootstrap CI. |
| `class_statistics.py` | Wilson confidence intervals; exact omnibus likelihood-ratio test for class–outcome association; per-class Firth odds ratios versus a reference class. |
| `requirements.txt` | Software dependencies and versions. |

## Methods implemented

- **Latent class analysis:** finite mixture of Bernoulli distributions fit by
  expectation-maximization (log-sum-exp E-step; 120 random initializations with
  a fixed seed to reduce the risk of local optima; class number selected by the
  Bayesian Information Criterion). Implements the latent-structure / finite-
  mixture framework (Lazarsfeld & Henry, 1968; McLachlan & Peel, 2000).
- **Firth penalized-likelihood logistic regression** for sparse-event settings
  (Firth, 1993; Heinze & Schemper, 2002).
- **Multiple-imputation pooling** by Rubin's rules (Rubin, 1987).

## Validation

The author-implemented Firth and latent-class routines were verified against
established reference implementations (R packages `logistf` and `poLCA`,
respectively) and agreed to within numerical tolerance.

## Environment

Developed and run under Python 3.12 with NumPy 2.4, pandas 3.0, SciPy 1.17,
scikit-learn 1.8, and Matplotlib 3.10. See `requirements.txt`.

## Usage

Latent class analysis (input: CSV with an ID column and binary indicator columns):

```
python lca_bernoulli.py --data indicators.csv --id record_id \
    --outcome death --kmin 2 --kmax 8 --restarts 120 --seed 42 \
    --out lca_assignments.csv
```

Firth regression and pooling routines are imported as functions; see docstrings
in `firth_logistic.py` and `class_statistics.py`.

## Citation

If you use this code, please cite the software (Zenodo DOI, added on release)
and the accompanying article.

## License

MIT License (see `LICENSE`).
