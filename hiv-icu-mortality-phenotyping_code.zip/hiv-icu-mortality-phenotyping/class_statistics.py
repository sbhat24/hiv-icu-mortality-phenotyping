"""
Helper statistics for phenotype comparison.

Provides Wilson score confidence intervals for proportions, the exact omnibus
likelihood-ratio test for association between a categorical class variable and a
binary outcome, and per-class Firth odds ratios versus a reference class.
"""
import numpy as np
import pandas as pd
from scipy import stats
from firth_logistic import firth_fit

def wilson_ci(k, n, z=1.96):
    """Wilson score interval for a proportion k/n. Returns (p, lo, hi) as percentages."""
    if n == 0:
        return (0.0, 0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    center = (p + z * z / (2 * n)) / d
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p * 100, max(0, center - half) * 100, min(1, center + half) * 100

def omnibus_lr(classes, outcome):
    """
    Exact likelihood-ratio test that in-class outcome rates differ across classes.
    For a categorical predictor, the MLE fitted probabilities equal per-class rates,
    so the full-model log-likelihood has a closed form. Returns (LR, df, p).
    """
    classes = np.asarray(classes); y = np.asarray(outcome, float)
    N = len(y); D = y.sum()
    ll_full = 0.0
    ks = np.unique(classes)
    for k in ks:
        yk = y[classes == k]; nk = len(yk); dk = yk.sum(); pk = dk / nk
        if 0 < pk < 1:
            ll_full += dk * np.log(pk) + (nk - dk) * np.log(1 - pk)
    yb = D / N
    ll_null = D * np.log(yb) + (N - D) * np.log(1 - yb)
    LR = 2 * (ll_full - ll_null)
    df = len(ks) - 1
    return LR, df, stats.chi2.sf(LR, df)

def per_class_or(classes, outcome, reference):
    """Firth odds ratios for each non-reference class vs the reference class."""
    classes = np.asarray(classes); y = np.asarray(outcome, float)
    levels = [c for c in sorted(np.unique(classes)) if c != reference]
    dummies = np.column_stack([(classes == c).astype(float) for c in levels])
    X = np.column_stack([np.ones(len(y)), dummies])
    fit = firth_fit(X, y)
    out = {}
    for i, c in enumerate(levels):
        out[c] = dict(odds_ratio=fit["odds_ratio"][i + 1],
                      ci_low=fit["ci_low"][i + 1], ci_high=fit["ci_high"][i + 1],
                      pvalue=fit["pvalue"][i + 1])
    return out
